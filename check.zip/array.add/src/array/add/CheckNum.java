package array.add;
import java.util.Scanner;

public class CheckNum
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int a[]=new int[5];
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		
		
		//System.out.println("enter a number:");
		int ch;
		while(true) {
			System.out.println("1.prime");
			System.out.println("2.palindrome");
			System.out.println("3.perfect");
			System.out.println("4.armstrong");
			System.out.println("5.quit");
			ch=sc.nextInt();
			
			switch(ch)
			{
			case 1:
				for(int i=0;i<a.length;i++)
			  {
					a[i]=sc.nextInt();
				int d=2;
				boolean b=true;
				while(d<=a[i]/2)
				{
					if(a[i]%d==0)
					{
						b=false;
						break;
					}
					d++;
				}
				if(b)
				{
					System.out.println(a[i] + "is a prime");
				}
				else
				{
					System.out.println(a[i] +"is not a prime");
				}
			  }
			case 2:
				for(int i=0;i<a.length;i++)
				{
					a[i]=sc.nextInt();
				int rev=0,temp=a[i];
				while(temp>0)
				  {
					rev=(rev*10)+(temp%10);
					temp=temp/10;
				   }
				if(a[i]==rev)
				{
					System.out.println(a[i] +"is  a palindrome");	
				}
				else
				{
					System.out.println(a[i] +"is not  a palindrome");
				}
				}
			case 3:
				for(int i=0;i<a.length;i++)
				{
					a[i]=sc.nextInt();
				int sum=0;int z;
				for(z=1;i<a[i];z++)
				{
					if(a[i]%z==0)
					{
					 sum=sum+z;	
					}
				}
				if(sum==a[i]) {
					System.out.println(a[i] +"is  a perfect");
				}
				else
				{
					System.out.println(a[i] +"is not a perfect");
				}
				}
			case 4:
				for(int i=0;i<a.length;i++)
				{
					a[i]=sc.nextInt();
				int rem=0;double result=0;
				while(a[i]!=0)
				{
					rem=a[i]%10;
					result=result+Math.pow(rem, 3);
					a[i]=a[i]/10;
				}
				if(result==a[i])
				{
					System.out.println(a[i] +"is  armstrong");
				}
				else
				{
					System.out.println(a[i]+"is not an armstrong");
				}
				}
			case 5:{
				System.out.println("quit");
			}	
			default:
			System.out.println("end of program");
				}
			}
		
	}
}
