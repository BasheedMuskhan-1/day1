package array.add;

import java.util.Scanner;

public class CommandLineArg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner sc=new Scanner(System.in);
     int n,rem=0,rev=0;
     if(args.length>0)
     {
    	 n=Integer.parseInt(args[0]);
    	 
     }
     else
     {
    	 System.out.println(" enterpositive number");
    	 n=sc.nextInt();
     }
    	 while(n!=0)
    	 {
    	 rem=n%10;
    	 rev=rev*10+rem;
    	 n=n/10;
     }
	System.out.println(rev);
     
		int d=2;
		boolean b=true;
		while(d<=rev/2)
		{
			if(rev%d==0)
			{
				b=false;
				break;
			}
			d++;
		}
		if(b)
		{
			System.out.println(rev + "is a prime");
		}
		else
		{
			System.out.println(rev +"is not a prime");
		}
}
     }